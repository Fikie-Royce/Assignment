## this is a blazor project which involves an inventory where users can add items to their inventory 
## there is also a homepage also known as dashboard , where all statistics concerning the inventory has been placed 
## this project is still in project but the main aim is to allow the user to access the dashboard after successful login , i will connect it to mysql later 
## and only logged in users can add items to the inventory
